const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('./user');

const Joi = require('@hapi/joi');

const registerSchema = Joi.object({
    email: Joi.string().min(6).required().email(),
    password: Joi.string().min(6).required(),
});

const loginSchema = Joi.object({
    email: Joi.string().min(6).required().email(),
    password: Joi.string().min(6).required(),
});


router.post('/login', async(req,res)=>{
    const user = await User.findOne({ email: req.body.email});
    if(!user){
        res.status(400).send('Email doesn\'t exists');
        return;
    }

    const validPassword = await bcrypt.compare(req.body.password, user.password);
    if (!validPassword) return res.status(400).send('Incorrect information');

    try{
        const {err} = await loginSchema.validateAsync(req.body);
        if(err){
            res.status(400).send(err.details[0].message);
            return;
        }else{
            const token = jwt.sign({_id: user._id}, 'randomString');
            res.header('suth-token', token).send(token);
        }
    }catch(err){
        res.status(500).send(err);
    }
});


router.post('/register', async(req,res)=>{
    const emailExist = await User.findOne({ email: req.body.email});
    if(emailExist){
        res.status(400).send('Email already exists');
        return;
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(req.body.password, salt);
    const user = new User({
        email: req.body.email,
        password: hashedPassword,
    });

    try{
        const {err} = await registerSchema.validateAsync(req.body);
        if(err){
            res.status(400).send(err.details[0].message);
            return;
        }else{
            const saveUser = await user.save();
            res.status(200).send('user created');
        }
    }catch(err){
        res.status(500).send(err);
    }
});

module.exports = router;