const User = require('./user');
const verify = require('./authVerify');
const router = require('express').Router();

router.get('/allusers', verify, async(req, res)=>{
    try{
        const results = await User.find().exec();
        res.send(results);
    }catch(err){
        res.status(500).send(err);
    }
});

module.exports = router;