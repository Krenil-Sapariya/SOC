const express = require('express');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoute = require('./auth');
const authDashboard = require('./authDashboard');
const { urlencoded } = require('body-parser');
dotenv.config();

mongoose.connect( "mongodb+srv://Krenil:krenil310@mydb.srg96.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    {useNewUrlParser: true,useUnifiedTopology: true },
    ()=>{
        console.log('connected!');
    }
);

const app = express();

app.get('/', (req, res)=>{
    res.send('Welcome to login API using jwt');
});

app.listen(5500, (req,res)=>{
    console.log('listening on 5500!');
});

app.use(express.json(), cors());
app.use('./user', authRoute);
app.use('/dashboard', authDashboard);