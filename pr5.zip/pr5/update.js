const Student = require('./schema');

module.exports = {
    update: (res, oldID, newID, newName, newSem)=>{
        Student.findOneAndUpdate(
            {id:oldID}, //find
            {id:newID, name:newName, sem:newSem}) //update
            .then(item=>res.send(item))
            .catch(err=>res.send(err));
    }
};