const Student = require('./schema')
const newStudent = (
    [
        {
            id:'19CE125',
            name:"Sapariya Krenil",
            sem:6
        },
        {
            id:'19DIT003',
            name:"Nishita Ardeshna",
            sem:6
        }
    ]    
);

module.exports = {
    insert: (Id, Name, Sem)=>{
        const student = new Student({
            id: Id,
            name: Name,
            sem:Sem
        })
        student.save().then(item=>console.log(item))
        .catch(err=>console.log(err));
    },

    insertMultiple: ()=>{
        Student.insertMany(newStudent).then(item=>console.log(item))
                                      .catch(err=>console.log(err));
    }
};