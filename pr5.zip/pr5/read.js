const res = require('express/lib/response');
const Student = require('./schema');

module.exports = {
    find: (res,Id)=>{
        Student.find({id:Id}).then(()=>{
            res.send('Data found!');
        }).catch((err)=>{
            res.send('Data not found!')
        })
    }
};