const mongoose = require('mongoose')
const db = require('./connectDB')

const schema = new mongoose.Schema({
    id:String,
    name:String,
    sem:Number
});

module.exports = mongoose.model('Student', schema, 'Students');