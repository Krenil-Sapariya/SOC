const mongoose = require('mongoose')

const DB = 'mongodb+srv://Krenil:krenil310@mydb.srg96.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'

mongoose.connect(DB).then(()=>{
    console.log('Connected');
}).catch((err)=>{
    console.log(err)
})