const express = require('express');
const app = express();
const DB = require('./connectDB');

const insert = require('./insert');
const read = require('./read');
const update = require('./update');
const del = require('./delete');

app.get('/', (req, res)=>{
    res.send('Welcome to CRUD web service!');
});

app.get('/insert', (req,res)=>{
    insert.insert('19CE000', 'Dummy', 6);
    insert.insertMultiple();
    res.send('Data inserted successfully!!')
});

app.get('/read', (req,res)=>{
    read.find(res,'19CE126');
});

app.get('/update', (req, res)=>{
    update.update(res, '19CE000' , '19CE001', 'NAME', 6);
});

app.listen(5500, ()=>{
    console.log('Listening on 5500');
});